### Update thời khóa biểu

- Bỏ file excel vào folder này
- `node convertExcelToData.js` 

 Sẽ update `tkb.json`

