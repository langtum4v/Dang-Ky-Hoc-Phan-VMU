# Tool Đăng Ký Học Phần UIT

- [Xem video hướng dẫn](https://www.youtube.com/watch?v=KmW7qu52dpE)
- [Ngó sơ qua tool đăng ký học phần](https://docs.google.com/spreadsheets/d/1DtVql2fZgBr2bwzHHVePjWf8gELXi5uK_wXD8aTppTw/edit#gid=200020773)
- [**Copy tool để dùng**](http://bit.ly/dkhp-uit-helper)
- [Giao diện đkhp của trường](https://loia5tqd001.github.io/Dang-Ky-Hoc-Phan-UIT/nem-mui-dkhp/)
- [**Tạo TKB từ danh sách lớp**](https://loia5tqd001.github.io/Dang-Ky-Hoc-Phan-UIT/tao-tkb/)


![preview-dkhp](https://user-images.githubusercontent.com/31364664/62817002-b08c9f00-bb59-11e9-9f80-3ae9ea651792.PNG)
<p align="center">Giao diện google sheets</p>

---

## Ngó sơ qua tool
<img src="./captures/preview-tool.png">

---

## Tạo TKB từ danh sách lớp
<img src="./captures/tao-tkb-2.png">

---

## Giao diện ĐKHP của trường
<img src="./captures/nem-mui-dkhp.png">



